<?php $__env->startSection('content'); ?>
<!-- seharusnya pada konten ini data yang ditampilkan adalah data akhir -->
    <div class="car p-3"> 
        <div class="car-baru p-3 mb- bg-white rounded">
            <div class="d-flex justify-content-between shadow p-3 mb-1 bg-white rounded">                
                <div class="search-input">
                    <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari nama / kode..."
                            class="border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">            

                        <button type="submit" class="bg-gray-800 text-white px-4 py-2 rounded-lg hover:bg-gray-900">
                            Filter
                        </button>
                    </form>
                </div>
            </div>
        </div>                        
        <div class="table-responsive shadow p-3 mb-2 bg-white rounded">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Nama Barang</th>
                        <th>SN</th>     
                        <th>Status</th>
                        <th>Tanggal</th>                        
                        <th>Action</th>                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tandater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>                                          
                        <td><?php echo e($data->id_tandater); ?></td>
                        <td>
                            <?php echo e($data->customer); ?>

                        </td>
                        <td>                            
                            <?php $__currentLoopData = $data->barang->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($barang->nama_barang); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </td>
                        <td>
                            <?php $__currentLoopData = $data->barang->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($barang->SN); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </td>                                                   
                        <td><?php echo e($data->garansi == 0 ? "Tidak Garansi" : "Garansi"); ?></td>
                        <td><?php echo e($data->created_at->format('Y-m-d')); ?></td>
                        <td class="d-flex gap-2">
                            <?php if($data->has_created != 1): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('list.finance', ['id' => $data->id])); ?>">Lihat</a>
                            <?php else: ?>
                                <a class="btn btn-primary disabled" href="<?php echo e(route('list.finance', ['id' => $data->id])); ?>">Lihat</a>
                            <?php endif; ?>
                            <a class="btn btn-success" href="<?php echo e(route('tampil.cetak', ['id' => $data->id_tandater])); ?>">Cetak</a>
                        </td>  
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                Belum ada data Tandater.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer bg-white border-0">
            <?php echo e($tandater->links('pagination::bootstrap-5')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('container.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\crm\DataPrint\mantem\mantem\resources\views/container/pages/finance.blade.php ENDPATH**/ ?>