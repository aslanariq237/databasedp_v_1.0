<?php $__env->startSection('content'); ?>
<!-- seharusnya pada konten ini data yang ditampilkan adalah data akhir -->
<div class="contain">  
    <form action="<?php echo e(route('trans.do')); ?>" method="GET" class="shadow p-3 mb-2 bg-white rounded">
        <?php echo csrf_field(); ?>   <!-- wajib kalau method="POST", tapi di sini kita pakai GET biar lebih sederhana untuk export -->

        <div class="date d-flex justify-content-end align-items-center mx-2 gap-2">
            <div>
                <label for="start_date" class="form-label small">Dari</label>
                <input type="date" name="start_date" id="start_date" class="form-control" required>
            </div>

            <div>
                <label for="end_date" class="form-label small">Sampai</label>
                <input type="date" name="end_date" id="end_date" class="form-control" required>
            </div>

            <div class="align-self-end">
                <button type="submit" class="btn btn-primary">Export Excel</button>
            </div>
        </div>
    </form>      
        <div class="table-responsive shadow p-3 mb-2 bg-white rounded">
            <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>id Transaksi</th>                    
                    <th>id invoice</th>
                    <th>Customer</th>
                    <th>Barang</th>
                    <th>Serial Number</th>
                    <th>Sub Barang</th>
                    <th>Sub Service</th>
                    <th>PPN</th>
                    <th>Total</th>
                    <th>Payment</th>   
                    <th>Date</th>             
                </tr>
            </thead>            
            <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tbody>
                    <tr>     
                        <td><?php echo e($loop->iteration + ($transaksi->currentPage() - 1) * $transaksi->perPage()); ?></td>       
                        <td><?php echo e($data->id_transaksi); ?> </td>                        
                        <td><?php echo e($data->no_invoice); ?> </td>                        
                        <td>
                            <?php if($data->nama_toko != null): ?>
                                <?php echo e($data->nama_toko); ?>

                            <?php else: ?>
                                <?php echo e($data->id_customer); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($data->nama_barang); ?> </td>
                        <td><?php echo e($data->SN); ?></td>
                        <td>Rp.<?php echo e(number_format($data->total_biaya, 0, ',','.')); ?></td>
                        <td>Rp.<?php echo e(number_format($data->jasa_service, 0, ',','.')); ?></td>
                        <td>Rp.<?php echo e(number_format($data->ppn, 0, ',','.')); ?></td>
                        <td>Rp.<?php echo e(number_format($data->total_biaya + $data->ppn, 0, ',','.')); ?></td>
                        <td><?php echo e($data->status_pay != 0 ? "Sudah Bayar" : "Belum Bayar"); ?></td>                  
                        <td><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('y M d')); ?> </td>
                    </tr>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td colspan="11" class="px-6 py-12 text-center text-gray-500">
                        Belum ada data transaksi.
                    </td>
            <?php endif; ?>              
        </table>
        </div>
        <div class="card-footer bg-white border-0">
            <?php echo e($transaksi->links('pagination::bootstrap-5')); ?>

        </div>
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('container.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projects\crm\DataPrint\mantem\mantem\resources\views/container/pages/transaksiData.blade.php ENDPATH**/ ?>