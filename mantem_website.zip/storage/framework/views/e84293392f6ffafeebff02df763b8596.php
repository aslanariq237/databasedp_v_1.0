<div class="px-3">
    <?php if(Auth::check()): ?>
        <div class="d-flex justify-content-between items-center gap-4">
            <div class="nama_employee">
                <p class="fw-semibold">Hola, <?php echo e(Auth::user()->name); ?></p>
            </div>
            <div class="button">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger ">LogOut</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <a href="<?php echo e(route('tampil.login')); ?>">Login</a>
    <?php endif; ?>
</div><?php /**PATH D:\Projects\crm\DataPrint\mantem\mantem\resources\views/template/navbar.blade.php ENDPATH**/ ?>