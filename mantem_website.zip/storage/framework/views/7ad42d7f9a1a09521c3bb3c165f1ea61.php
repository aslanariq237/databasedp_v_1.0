<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/Auth/login.css">
    <title>Login ManageTem</title>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="title">
                <h3>Login as Admin</h3>
            </div>
            <p>Welcome! Please Log In with your Account</p>
            <div class="form">
                <form action="<?php echo e(route('req.admin')); ?>" method="POST">                
                    <?php echo csrf_field(); ?>
                    <input type="email" name="email" placeholder="Enter your Email">
                    <input type="password" name="password" placeholder="Enter your Password">
                    <button>Sign In</button>
                    <div class="r1">
                        <a href="<?php echo e(route('tampil.teknisi')); ?>">Login as Teknisi</a>
                        <a href="<?php echo e(route('tampil.admin')); ?>">Login as Admin</a>
                    </div>
                    <a href="<?php echo e(route('tampil.regis')); ?>">Dont have an Account yet?<span>Sign Up</span></a>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Projects\crm\DataPrint\mantem\mantem\resources\views/Auth/LogAdmin.blade.php ENDPATH**/ ?>