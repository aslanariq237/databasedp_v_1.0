<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Keluhan;

class KeluhanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Keluhan::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {        
        $keluhan = new Keluhan();
        $keluhan->keluhan = $request->keluhan;
        $keluhan->biaya_keluhan = $request->biaya_keluhan;
        if($keluhan->save()){
            return ["status" => "Data Keluhan di tambahkan"];        
        }else{
            return ["status" => "Data Keluhan Gagal di Tambahkan"];
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
